<?php $__env->startSection('title'); ?> Inicio - <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_description'); ?>  <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .modalContainer {
            display: none;
            position: fixed;
            z-index: 1;
            padding-top: 80px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: #6e420dd9;
        }

        .modalContainer .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px lightgray;
            border-top: 30px solid #dbba01;
            width: 70%;
            border-radius: 5px;
            color: #925914;
        }

        .modalContainer .close {
            color: #ffffff;
            float: right;
            font-size: 40px;
            font-weight: bold;
            position: absolute;
            right: 10px;
            top: 0px;
        }

        .modalContainer .close:hover,
        .modalContainer .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }

        #titulo {
            text-align: center;
            font-size: 38px;
            margin: 0px;
            margin-bottom: 20px;
            font-family: "Caesar Dressing";
        }

        #cont {
            font-size: 26px;
            text-align: center;
            font-family: "Caesar Dressing";
        }

        a.btn {
            padding: 10px;
            background-color: #942121;
            border-radius: 5px;
            color: white;
            text-decoration: none;
            box-shadow: 0 0 10px rgb(0 0 0 / 30%);
        }
        
        a.btn:hover {
            background-color: #b22727;
        }

        .btn-success{
            background-color: #409421;
        }

        .caja-codigo{
            font-family: Arial, Helvetica, sans-serif;
            text-align:center;
            font-size:40px;
            padding:10px;
            background-color:#925914;
            color:white;
            border-radius: 5px;
            box-shadow: inset 5px 5px 15px rgb(0 0 0 / 50%);
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('aventura/Registro.js?'.Str::random(10))); ?>"></script>
    <script>
        var canvas, stage, exportRoot, anim_container, dom_overlay_container, fnStartAnimation;
        function init() {
            canvas = document.getElementById("canvas");
            anim_container = document.getElementById("animation_container");
            dom_overlay_container = document.getElementById("dom_overlay_container");
            var comp=AdobeAn.getComposition("F8271C36107E614EA77AF8C8DF63843B");
            var lib=comp.getLibrary();
            try {
                if(!(typeof gFontsFamilies === 'undefined' || gFontsFamilies === null))
                    LoadGFonts(gFontsFamilies, comp);		
                if(!(typeof totalTypekitFonts === 'undefined' || totalTypekitFonts === null)) {			
                    var typekitObject = {type: 'Typekit', loadedFonts: 0, totalFonts: totalTypekitFonts, callOnLoad: lib.tfontAvailable};		
                    Typekit.load({
                    async: true,
                    'fontactive': function(family) {
                        isFontAvailable(family, typekitObject);
                        }
                    });
                }
            } catch(e) {};
            var loader = new createjs.LoadQueue(false);
            loader.installPlugin(createjs.Sound);
            loader.addEventListener("complete", function(evt){handleComplete(evt,comp)});
            var lib=comp.getLibrary();
            loader.loadManifest(lib.properties.manifest);
        }
        function handleComplete(evt,comp) {
            //This function is always called, irrespective of the content. You can use the variable "stage" after it is created in token create_stage.
            var lib=comp.getLibrary();
            var ss=comp.getSpriteSheet();
            var queue = evt.target;
            var ssMetadata = lib.ssMetadata;
            for(i=0; i<ssMetadata.length; i++) {
                ss[ssMetadata[i].name] = new createjs.SpriteSheet( {"images": [queue.getResult(ssMetadata[i].name)], "frames": ssMetadata[i].frames} )
            }
            var preloaderDiv = document.getElementById("_preload_div_");
            preloaderDiv.style.display = 'none';
            dom_overlay_container.style.display = canvas.style.display = 'block';
            exportRoot = new lib.Registro();
            exportRoot.addEventListener("tick", AdobeAn.handleFilterCache);
            stage = new lib.Stage(canvas);
            stage.enableMouseOver();	
            //Registers the "tick" event listener.
            fnStartAnimation = function() {
                stage.addChild(exportRoot);
                createjs.Ticker.framerate = lib.properties.fps;
                createjs.Ticker.addEventListener("tick", stage);
            }	    
            //Code to support hidpi screens and responsive scaling.
            AdobeAn.makeResponsive(true,'both',true,1,[canvas,preloaderDiv,anim_container,dom_overlay_container]);	
            AdobeAn.compositionLoaded(lib.properties.id);
            fnStartAnimation();
        }
        function playSound(id, loop, offset) {
            return createjs.Sound.play(id, {'interrupt':createjs.Sound.INTERRUPT_EARLY, 'loop': loop, 'offset': offset});
        }
    </script>
 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <audio class="audio-channel" src="<?php echo e(asset('audios/fondo.mp3')); ?>" autoplay hidden loop></audio>
	<audio class="audio-channel" src=""></audio>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.aventura', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/saludable/resources/views/app/inicio.blade.php ENDPATH**/ ?>