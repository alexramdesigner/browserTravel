
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    
    <title><?php echo $__env->yieldContent('title',''); ?> <?php echo e(setting('site.title')); ?></title>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0, minimum-scale=1.0, shrink-to-fit=no">
    <!--<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />-->
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description',setting('site.description')); ?>">
    <meta name="author" content="Inggen - John Alexander Ramirez">

    <meta name="format-detection" content="telephone=yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <?php echo $__env->yieldContent('metas'); ?>

    <link rel='canonical' href='<?php echo e(url()->current()); ?>' />
    <link rel="alternate" hreflang="x-default" href="<?php echo e(url()->current()); ?>" />
    <meta name="theme-color" content="#000000">
    <meta name="msapplication-TileColor" content="#000000">
    <meta name="msapplication-TileImage" content="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">

    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700,900" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('icon-fonts/fontawesome-5.8.1/css/all.min.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">

    <?php echo $__env->yieldContent('css'); ?>

  	<!--[if lt IE 9]>
  	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  	<![endif]--> 

</head>

	<body>

        <?php echo $__env->yieldContent('preloader'); ?>

        <main>

            <header>
                <a href="<?php echo e(route('home')); ?>" class="logo">
                    <img src="<?php echo e(asset('img/logo.png')); ?>">
                </a>
                <div class="menu">
                    <span></span>
                    <span></span>
                </div>
            </header>

            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->yieldContent('slider'); ?>
            <?php echo $__env->yieldContent('slider_bottom'); ?>

            <div class="right-menu">
                <div class="menu-close"></div>
                <div class="page-menu">
                    <ul>
                        <li><a data-type="ajax-load" href="<?php echo e(route('home')); ?>">Inicio</a></li>
                        <li><a data-type="ajax-load" href="<?php echo e(route('nosotros')); ?>">Nosotros</a></li>
                        <li><a data-type="ajax-load" href="<?php echo e(route('contacto')); ?>">Contacto</a></li>
                </div>
            </div>

        </main>

		<script src="<?php echo e(asset('js/jquery-2.1.4.min.js')); ?>"></script>
		<script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
		<script src="<?php echo e(asset('js/main.js')); ?>"></script>
		

	</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/inggen/resources/views/layouts/portal.blade.php ENDPATH**/ ?>