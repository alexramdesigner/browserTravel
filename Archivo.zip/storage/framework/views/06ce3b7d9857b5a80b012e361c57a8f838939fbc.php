<?php $__env->startSection('title'); ?> Inicio - <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_description'); ?>  <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('preloader'); ?>
    <div id="preloader">
        <div class="spinner">
            <div class="uil-ripple-css" style="transform:scale(0.29);"><div></div><div></div></div>
        </div>
    </div>

    <div class="page-loader show"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="smooth-scroll">

        <!-- PAGE ==================================================-->
        <div class="container text-left subpage">
            <div class="space80"></div>
            
            <h1 class="page-title box-animation">Contact Us</h1>
            <div class="space30"></div>
            <p class="subtext box-animation"  data-delay="200">I'm a designer & front end developer, currently <span>based in Los Angeles.</span> I'm passionate about quality code and security.</p>

            <div class="space80"></div>
            

            <!-- MAP ==================================================-->
            <div class="contact-map top_90 box-animation">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d36479.43458460815!2d-118.3131125302928!3d34.05808678462837!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c2c75ddc27da13%3A0xe22fdf6f254608f4!2sLos+Angeles%2C+Kaliforniya%2C+Birle%C5%9Fik+Devletler!5e0!3m2!1str!2str!4v1551872109031" height="450" style="border:0" allowfullscreen=""></iframe>
            </div>

            <div class="space80"></div>

            <!-- CONTACT INFO ==================================================-->
            <div class="getintouch row">
                <!-- contact info -->
                <div class="col-lg-4 contact-info box-animation">
                    <!-- info -->
                    <div class="info">
                        <i class="fas fa-paper-plane"></i>
                        <a href="#">hello@maclaren.com</a>
                        <p> Email </p>
                    </div>
                    <div class="space30"></div>
                    <!-- info -->
                    <div class="info">
                        <i class="fas fa-map-marker-alt"></i>
                        <p class="text">1444 S. Alameda Street Los Angeles,<br>California 90021</p>
                        <p> Address </p>
                    </div>
                    <div class="space30"></div>
                    <!-- info -->
                    <div class="info">
                        <i class="fas fa-phone"></i>
                        <a href="#">0800 123 456789</a>
                        <p> Phone </p>
                    </div>
                </div>
                
                <div class="col-lg-8 contact-form box-animation">
                    <!-- contact form -->
                    <div class="space30"></div>
                    <form class="contact-form">
                        <div class="row">
                            <!--Name-->
                            <div class="col-md-6">
                                <input class="form-inp" type="text" placeholder="Name">
                            </div>
                            <!--Email-->
                            <div class="col-md-6">
                                <input class="form-inp" type="text" placeholder="Email">
                            </div>
                            <div class="col-md-12">
                                <!--Message-->
                                <textarea placeholder="How can I help you?" rows="7"></textarea>
                                <div class="space50"></div>
                                <button id="con_submit" class="site-btn top_45 pull-right" type="submit">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>

        <!-- FOOTER ==================================================-->
        <footer>
            <div class="back-top float-left">
                <i class="fas fa-chevron-up"></i> <p>Back to Top</p>
            </div>
            <div class="float-left copyright">
                <p>2019 copyright © tavonline</p>
            </div>
            <!-- Social Links -->
            <div class="social float-right">
                <a href="#"><i class="fab fa-facebook-f"></i>  </a>
                <a href="#"><i class="fab fa-twitter" aria-hidden="true"></i>  </a>
                <a href="#"><i class="fab fa-instagram" aria-hidden="true"></i>  </a>
                <a href="#"><i class="fab fa-behance" aria-hidden="true"></i>  </a>
                <a href="#"><i class="fab fa-dribbble" aria-hidden="true"></i>  </a>
            </div>
        </footer>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/inggen/resources/views/app/contacto.blade.php ENDPATH**/ ?>