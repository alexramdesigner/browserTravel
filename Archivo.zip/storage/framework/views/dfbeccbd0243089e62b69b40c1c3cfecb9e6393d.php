<?php $__env->startSection('title'); ?> Gachancipá - Nemocón | <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_description'); ?>  <?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('aventura/M2.js??'.Str::random(10))); ?>"></script>
    <script>
        var canvas, stage, exportRoot, anim_container, dom_overlay_container, fnStartAnimation;
        function init() {
            canvas = document.getElementById("canvas");
            anim_container = document.getElementById("animation_container");
            dom_overlay_container = document.getElementById("dom_overlay_container");
            var comp=AdobeAn.getComposition("81EFA579EEA049E3A285A308E94A8C7A");
            var lib=comp.getLibrary();
            try {
                if(!(typeof gFontsFamilies === 'undefined' || gFontsFamilies === null))
                    LoadGFonts(gFontsFamilies, comp);		
                if(!(typeof totalTypekitFonts === 'undefined' || totalTypekitFonts === null)) {			
                    var typekitObject = {type: 'Typekit', loadedFonts: 0, totalFonts: totalTypekitFonts, callOnLoad: lib.tfontAvailable};		
                    Typekit.load({
                    async: true,
                    'fontactive': function(family) {
                        isFontAvailable(family, typekitObject);
                        }
                    });
                }
            } catch(e) {};
            var loader = new createjs.LoadQueue(false);
            loader.installPlugin(createjs.Sound);
            loader.addEventListener("fileload", function(evt){handleFileLoad(evt,comp)});
            loader.addEventListener("complete", function(evt){handleComplete(evt,comp)});
            var lib=comp.getLibrary();
            loader.loadManifest(lib.properties.manifest);
        }
        function handleFileLoad(evt, comp) {
            var images=comp.getImages();	
            if (evt && (evt.item.type == "image")) { images[evt.item.id] = evt.result; }	
        }
        function handleComplete(evt,comp) {
            //This function is always called, irrespective of the content. You can use the variable "stage" after it is created in token create_stage.
            var lib=comp.getLibrary();
            var ss=comp.getSpriteSheet();
            var queue = evt.target;
            var ssMetadata = lib.ssMetadata;
            for(i=0; i<ssMetadata.length; i++) {
                ss[ssMetadata[i].name] = new createjs.SpriteSheet( {"images": [queue.getResult(ssMetadata[i].name)], "frames": ssMetadata[i].frames} )
            }
            var preloaderDiv = document.getElementById("_preload_div_");
            preloaderDiv.style.display = 'none';
            canvas.style.display = 'block';
            exportRoot = new lib.M2();
            stage = new lib.Stage(canvas);
            stage.enableMouseOver();	
            //Registers the "tick" event listener.
            fnStartAnimation = function() {
                stage.addChild(exportRoot);
                createjs.Ticker.framerate = lib.properties.fps;
                createjs.Ticker.addEventListener("tick", stage);
            }	    
            //Code to support hidpi screens and responsive scaling.
            AdobeAn.makeResponsive(true,'both',true,1,[canvas,preloaderDiv,anim_container,dom_overlay_container]);	
            AdobeAn.compositionLoaded(lib.properties.id);
            fnStartAnimation();
        }
        function playSound(id, loop, offset) {
            return createjs.Sound.play(id, {'interrupt':createjs.Sound.INTERRUPT_EARLY, 'loop': loop, 'offset': offset});
        }
    </script>
 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<audio class="audio-channel" src="<?php echo e(asset('audios/mod2/fondo.mp3')); ?>" autoplay hidden loop></audio>
<audio class="audio-channel" src=""></audio>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.aventura', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/saludable/resources/views/app/modulo2.blade.php ENDPATH**/ ?>