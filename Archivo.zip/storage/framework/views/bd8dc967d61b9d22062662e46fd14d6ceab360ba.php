<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    
    <title><?php echo $__env->yieldContent('title',''); ?> <?php echo e(setting('site.title')); ?></title>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0, minimum-scale=1.0, shrink-to-fit=no">
    <!--<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />-->
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description',setting('site.description')); ?>">
    <meta name="author" content="Inggen - John Alexander Ramirez">

    <meta name="format-detection" content="telephone=yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <?php echo $__env->yieldContent('metas'); ?>

    <link rel='canonical' href='<?php echo e(url()->current()); ?>' />
    <link rel="alternate" hreflang="x-default" href="<?php echo e(url()->current()); ?>" />
    <meta name="theme-color" content="#000000">
    <meta name="msapplication-TileColor" content="#000000">
    <meta name="msapplication-TileImage" content="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(Voyager::image(setting('site.favicon'))); ?>">

    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Lato:900&subset=latin">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Lato:regular&subset=latin">

    <link rel="stylesheet" href="<?php echo e(asset('css/notify.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>">

    <?php echo $__env->yieldContent('css'); ?>
    
    
    <script src="<?php echo e(asset('js/createjs.min.js')); ?>"></script>
    <script> <!-- fonts -->
        function LoadGFonts(families, comp) {
            var lib = comp.getLibrary();
            var googleObject = {
                type: "Google",
                loadedFonts: 0,
                totalFonts: families.length,
                callOnLoad: lib.gfontAvailable
            };
            for (var i = 0; i < families.length; i++)
                isFontAvailable(gFontsFamilies[i], googleObject);
        }
        function isFontAvailable(font, obj) {
            var timeOut = 5000;
            var delay = 200;
            var interval = 0;
            var timeElapsed = 0;

            function checkFont() {
                var node = document.createElement("span");
                node.innerHTML = "giItT1WQy@!-/#";
                node.style.position = "absolute";
                node.style.left = "-1000px";
                node.style.top = "-1000px";
                node.style.fontSize = "300px";
                node.style.fontFamily = "sans-serif";
                node.style.fontVariant = "normal";
                node.style.fontStyle = "normal";
                node.style.fontWeight = "normal";
                node.style.letterSpacing = "0";
                document.body.appendChild(node);
                var width = node.offsetWidth;
                node.style.fontFamily = font + "," + node.style.fontFamily;
                var returnVal = false;
                if ((node && node.offsetWidth != width) || timeElapsed >= timeOut) {
                    obj.loadedFonts++;
                    if (interval)
                        clearInterval(interval);
                    obj.callOnLoad(font, obj.totalFonts);
                    returnVal = true;
                }
                if (node) {
                    node.parentNode.removeChild(node);
                    node = null;
                }
                timeElapsed += delay;
                return returnVal;
            }
            if (!checkFont()) {
                interval = setInterval(checkFont, delay);
            }
        }
        var gFontsFamilies = ["Lato"];
    </script>

    <?php echo $__env->yieldContent('js'); ?>


    <script src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>"></script>
    <script>
        $.ajaxSetup({ headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}});
        
        function jarAlert(title, message,type){
            var notify = new Notify();
            notify.render({ head: title, content: message, style: type, sound: true});
        }
    </script>
</head>

<body onload="init();" style="margin:0px;background:url(<?php echo e(asset('images/fondo_inicio.jpg')); ?>); background-size: cover;">

    <div id="tvesModal" class="modalContainer" style="display:none;">
        <div class="modal-content">
           <span class="close">×</span>
           <h2 id="titulo"></h2>
           <div id="cont"></div>
           <div class="loader-bars mt-3 text-center" style="display: none;">
               <img src="images/_preloader.gif" width="40">
           </div>
       </div>
   </div>

    <div class="overlay"></div>
    <div id="animation_container" style="box-shadow: 0 0 50px rgba(0,0,0,.4); width:100%; height:100%">
        <canvas id="canvas" width="100%" height="100%" style="position: absolute; display: block;"></canvas>
        <div id="dom_overlay_container" style="pointer-events:none; overflow:hidden; width:100%; height:100%; position: absolute; left: 0px; top: 0px; display: block;">
        </div>
    </div> 
    <div id='_preload_div_' style='position:absolute; top:0; left:0; display: inline-block; height:100%; width: 100%; text-align: center;'> <span style='display: inline-block; height: 100%; vertical-align: middle;'></span> <img src=<?php echo e(asset('images/_preloader.gif?1652280050413')); ?> width="150px" style='vertical-align: middle; max-height: 100%' /></div>

    <?php echo $__env->yieldContent('content'); ?>

    <script src="<?php echo e(asset('js/notify.js')); ?>"></script>

    <script>
        var modal = document.getElementById("tvesModal");
        var body = document.getElementsByTagName("body")[0];
        var span = document.getElementsByClassName("close")[0];
        var body = document.getElementsByTagName("body")[0];
        var titulo = document.getElementById("titulo");
        var cont = document.getElementById("cont");

        function abre_modal(title,contenido){

            cont.innerHTML='';

            modal.style.display = "block";

            body.style.position = "static";
            body.style.height = "100%";
            body.style.overflow = "hidden";

            $('.loader-bars').hide();

            titulo.innerHTML = title;
            cont.innerHTML = contenido;

            /*$.ajax({
                url:"/feria/sorteo/ganadores",type:'GET',data:{stand:stand},
                beforeSend: function() { $('.loader-bars').show(); },complete: function(){ $('.loader-bars').hide(); },
            }).done(function(data){
                if(data.valid){cont.innerHTML=data.html;}
            });*/

        }

        
        span.onclick = function() {
            modal.style.display = "none";

            body.style.position = "inherit";
            body.style.height = "auto";
            body.style.overflow = "visible";
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";

                body.style.position = "inherit";
                body.style.height = "auto";
                body.style.overflow = "visible";
            }
        }
    </script>

</body>

</html><?php /**PATH /Applications/MAMP/htdocs/saludable/resources/views/layouts/aventura.blade.php ENDPATH**/ ?>