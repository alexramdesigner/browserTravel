<tbody>
    <?php $__currentLoopData = $weather; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($weat->created_at); ?></td>
            <td><img id="icon" src="<?php echo e($weat->icon); ?>" width="30"></td>
            <td><?php echo e($weat->temp); ?>°C - <?php echo e($weat->description); ?></td>
            <td>Sensación T. <?php echo e($weat->feels_like); ?>°C</td>
            <td><?php echo e($weat->humidity); ?>% <i class="fa-solid fa-umbrella"></i></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody><?php /**PATH /Applications/MAMP/htdocs/browserTravel/resources/views/partials/historial.blade.php ENDPATH**/ ?>