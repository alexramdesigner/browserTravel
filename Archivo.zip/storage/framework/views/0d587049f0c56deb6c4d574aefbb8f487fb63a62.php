<?php $__env->startSection('title'); ?> Inicio - <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_description'); ?>  <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('preloader'); ?>
    <div id="preloader">
        <div class="spinner">
            <div class="uil-ripple-css" style="transform:scale(0.29);"><div></div><div></div></div>
        </div>
    </div>

    <div class="page-loader show"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="smooth-scroll">
        
        <div class="space80"></div>
        <!-- PAGE ==================================================-->
        <div class="container text-left subpage">
            <h1 class="page-title box-animation"  data-delay="100">Acerca de</h1>
            <div class="space30"></div>
            <p class="subtext box-animation"  data-delay="200">Soy desarrollador full stack, actualmente me ubico en <span>Colombia.</span> Soy un apasioando por la seguridad y el código.</p>
            <p></p>
            <div class="space50"></div>
        
            <!-- SERVICES
            ==================================================-->
            <h2 class="subtitle box-animation" data-delay="400">Servicios</h2>
            <div class="space30"></div>
            <div class="services row box-animation" data-delay="600">
                <div class="col-lg-3 col-sm-6 service">
                    <i class="fas fa-desktop"></i>
                    <h2>web development</h2>
                    <p>Her extensive perceived may any sincerity extremity.</p>
                </div>
                <div class="col-lg-3 col-sm-6 service">
                    <i class="fas fa-paint-roller"></i>
                    <h2>graphic design</h2>
                    <p>Her extensive perceived may any sincerity extremity.</p>
                </div>
                <div class="col-lg-3 col-sm-6 service">
                    <i class="fas fa-lightbulb"></i>
                    <h2>brainstorming</h2>
                    <p>Her extensive perceived may any sincerity extremity.</p>
                </div>
                <div class="col-lg-3 col-sm-6 service">
                    <i class="fas fa-life-ring"></i>
                    <h2>friendly support</h2>
                    <p>Her extensive perceived may any sincerity extremity.</p>
                </div>
            </div>
        
            <div class="space80"></div>
            <!-- CLIENTS ==================================================-->
            <div class="clients box-animation">
                <h2 class="subtitle box-animation">Nuestros clientes</h2>
                <div class="row">
                    <div class="col-lg-3 client">
                        <img src="img/client-1.jpg" alt="">
                    </div>
                    <div class="col-lg-3 client">
                        <img src="img/client-2.jpg" alt="">
                    </div>
                    <div class="col-lg-3 client">
                        <img src="img/client-3.jpg" alt="">
                    </div>
                    <div class="col-lg-3 client">
                        <img src="img/client-4.jpg" alt="">
                    </div>
                </div>
            </div>
            
            <div class="space80"></div>
        
        
            <!-- CONTACT BUTTON ==================================================-->
            <div class="contact-link box-animation">
                <p class="subtext">We manufacture a hard copy  of your <br>dreams and stories.</p>
                <div class="space50"></div>
                <a data-type="ajax-load" data-hover="Contáctenos" href="<?php echo e(route('contacto')); ?>" class="contact-btn top_30">Contáctenos</a>
            </div>
            
        </div>
        
        
        <!-- FOOTER ==================================================-->
        <footer>
            <div class="back-top float-left">
                <i class="fas fa-chevron-up"></i> <p>Ir arriba</p>
            </div>
            <div class="float-left copyright">
                <p>2022 copyright © Inggen</p>
            </div>
            <!-- Social Links -->
            <div class="social float-right">
                <a href="#"><i class="fab fa-facebook-f"></i>  </a>
                <a href="#"><i class="fab fa-twitter" aria-hidden="true"></i>  </a>
                <a href="#"><i class="fab fa-instagram" aria-hidden="true"></i>  </a>
                <a href="#"><i class="fab fa-behance" aria-hidden="true"></i>  </a>
                <a href="#"><i class="fab fa-dribbble" aria-hidden="true"></i>  </a>
            </div>
        </footer>
    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/inggen/resources/views/app/nosotros.blade.php ENDPATH**/ ?>