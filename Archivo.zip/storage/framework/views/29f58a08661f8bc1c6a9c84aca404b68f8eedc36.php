<?php $__env->startSection('title'); ?> Inicio - <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_description'); ?>  <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('preloader'); ?>
    <div id="preloader" class="preloader-main">
        <div class="preloader spinner-jumper-container"><div class="spinner-section top"><div class="rotator"></div></div><div class="spinner-section bottom"><div class="rotator"></div></div></div>
    </div>

    <div class="page-loader show"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('slider'); ?>
    <div class="page-view">
        <div class="project">
            <div class="text">
                <span class="categorie hello">Hola a todos</span>
                <h1 class="title">Somos Inggen</h1>
                <a data-type="ajax-load" href="<?php echo e(route('nosotros')); ?>" class="see-more">Conocer más</a>
            </div>
            <div class="image" style="background-image: url(<?php echo e(asset('img/about.jpg')); ?>);"></div>
        </div>
        <div class="project">
            <div class="text">
                <span class="categorie">Basketball</span>
                <span class="number">02</span>
                <h1 class="title">Kevin Love</h1>
                <a data-type="ajax-load" href="portfolio-two.html" class="see-more">see more</a>
            </div>
            <div class="image" style="background-image: url(img/works/work-2/01.jpg);"></div>
        </div>
        <div class="project">
            <div class="text">
                <span class="categorie">Lifestyle</span>
                <span class="number">03</span>
                <h1 class="title">Isolation</h1>
                <a data-type="ajax-load" href="portfolio-three.html" class="see-more">see more</a>
            </div>
            <div class="image" style="background-image: url(img/works/work-3/01.jpg);"></div>
        </div>
        <div class="project">
            <div class="text">
                <span class="categorie">Fitness</span>
                <span class="number">04</span>
                <h1 class="title">Exo Protein</h1>
                <a data-type="ajax-load" href="portfolio-four.html" class="see-more">see more</a>
            </div>
            <div class="image" style="background-image: url(img/works/work-4/01.jpg);"></div>
        </div>
        <div class="project">
            <div class="text">
                <span class="categorie">Branding</span>
                <span class="number">05</span>
                <h1 class="title">Vokyl Erupt</h1>
                <a data-type="ajax-load" href="portfolio-five.html" class="see-more">see more</a>
            </div>
            <div class="image" style="background-image: url(img/works/work-5/01.jpg);"></div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('slider_bottom'); ?>
    <div class="slider-bottom">
        <!-- left arrows -->
        <div class="arrows">
            <div class="arrow previous">
                <i class="fas fa-angle-left"></i>
            </div>
            <div class="arrow next">
                <i class="fas fa-angle-right"></i>
            </div>
        </div>
        
        <!-- All Projects -->
        <a class="all-link" href="all-projects.html" data-type="ajax-load">Ver todos los proyectos</a>
        
        <!-- Social Links -->
        <div class="social float-right">
            <a href="#"><i class="fab fa-facebook-f"></i>  </a>
            <a href="#"><i class="fab fa-twitter" aria-hidden="true"></i>  </a>
            <a href="#"><i class="fab fa-instagram" aria-hidden="true"></i>  </a>
            <a href="#"><i class="fab fa-behance" aria-hidden="true"></i>  </a>
            <a href="#"><i class="fab fa-dribbble" aria-hidden="true"></i>  </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/inggen/resources/views/app/inicio.blade.php ENDPATH**/ ?>